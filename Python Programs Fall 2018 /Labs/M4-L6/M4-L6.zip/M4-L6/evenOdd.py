even = 50
eve = "The sum of even numbers: "
while even <=100:
    eve+= str(even) + ", "
    even += 2
print('\n')
print(eve)
odd = 51
od = 'The sum of odd numbers: '
while odd <=100:
    od+= str(odd) + ', '
    odd += 2
print(od)
