word = str(input('Enter word here: '))
for index,word in enumerate(word,1):
    print(index,":",word)
