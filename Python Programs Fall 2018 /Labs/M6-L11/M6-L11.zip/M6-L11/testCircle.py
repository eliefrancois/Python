from circle import circle
c1 = circle(1)
print(c1)
print('the Area is ' + str(c1.getArea()))
print('The perimeter is ' + str(c1.getPerimeter()))
c1.setRadius(10)
print('The circle has a radius of ' + str(c1.getRadius()))
print('The area is ' + str(c1.getArea()))
print('The perimeter is ' + str(c1.getPerimeter()))
