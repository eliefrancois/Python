row = 15
for i in range(1,16,2):
    print(' '*row+i*'*')
    row=row-1
    
