def displaySums(n):
    displaySums = n/(n+1)
    return displaySums
def main():
    n = float(input('Enter number here: '))
    print('The sum is:', displaySums(n))
main()
