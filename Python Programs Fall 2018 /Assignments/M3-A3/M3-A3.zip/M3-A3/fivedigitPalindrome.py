num1 = int(input('enter number here: '))
num2 = int(input('enter number here: ')) 
num3 = int(input('enter number here: ')) 
num4 = int(input('enter number here: ')) 
num5 = int(input('enter number here: ')) 

if num1/num5 == 1 and num2/num4 == 1:
    print ('this number is a palindrome')
elif num1/num5 != 1 and num2/num4 != 1:
    print ('this number is invaild')
